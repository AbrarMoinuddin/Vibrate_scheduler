package com.abrar.vibratescheduler

import android.app.AlarmManager
import android.app.NotificationManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.abrar.vibratescheduler.databinding.ActivityMainBinding
import com.abrar.vibratescheduler.databinding.DialogAddScheduleBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: ScheduleAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val schedules = ScheduleStorage.getAll(this)
        adapter = ScheduleAdapter(
            schedules = schedules,
            onToggle = ::onToggleSchedule,
            onDelete = ::onDeleteSchedule
        )
        binding.scheduleRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.scheduleRecyclerView.adapter = adapter

        binding.addButton.setOnClickListener { showAddScheduleDialog() }
        binding.permissionBanner.setOnClickListener { requestDndAccess() }

        refreshList()
    }

    override fun onResume() {
        super.onResume()
        updatePermissionBanner()
    }

    private fun onToggleSchedule(schedule: Schedule, enabled: Boolean) {
        schedule.enabled = enabled
        val all = ScheduleStorage.getAll(this).map { if (it.id == schedule.id) schedule else it }
        ScheduleStorage.saveAll(this, all)
        if (enabled) {
            AlarmScheduler.scheduleOne(this, schedule)
        } else {
            AlarmScheduler.cancelOne(this, schedule)
        }
        refreshList()
    }

    private fun onDeleteSchedule(schedule: Schedule) {
        AlarmScheduler.cancelOne(this, schedule)
        val remaining = ScheduleStorage.getAll(this).filter { it.id != schedule.id }
        ScheduleStorage.saveAll(this, remaining)
        refreshList()
    }

    private fun showAddScheduleDialog() {
        val dialogBinding = DialogAddScheduleBinding.inflate(layoutInflater)
        dialogBinding.onTimePicker.setIs24HourView(true)
        dialogBinding.offTimePicker.setIs24HourView(true)

        AlertDialog.Builder(this)
            .setTitle("Add schedule")
            .setView(dialogBinding.root)
            .setPositiveButton("Save") { _, _ ->
                val schedule = Schedule(
                    id = ScheduleStorage.nextId(this),
                    onHour = dialogBinding.onTimePicker.hour,
                    onMinute = dialogBinding.onTimePicker.minute,
                    offHour = dialogBinding.offTimePicker.hour,
                    offMinute = dialogBinding.offTimePicker.minute,
                    enabled = true
                )
                val all = ScheduleStorage.getAll(this) + schedule
                ScheduleStorage.saveAll(this, all)
                AlarmScheduler.scheduleOne(this, schedule)
                refreshList()
                checkExactAlarmPermission()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun refreshList() {
        val schedules = ScheduleStorage.getAll(this)
        adapter.updateData(schedules)
        binding.emptyStateText.visibility = if (schedules.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun updatePermissionBanner() {
        val notificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        binding.permissionBanner.visibility =
            if (notificationManager.isNotificationPolicyAccessGranted) View.GONE else View.VISIBLE
    }

    private fun requestDndAccess() {
        startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
    }

    private fun checkExactAlarmPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val alarmManager = getSystemService(ALARM_SERVICE) as AlarmManager
            if (!alarmManager.canScheduleExactAlarms()) {
                val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                    data = Uri.parse("package:$packageName")
                }
                startActivity(intent)
            }
        }
    }
}
