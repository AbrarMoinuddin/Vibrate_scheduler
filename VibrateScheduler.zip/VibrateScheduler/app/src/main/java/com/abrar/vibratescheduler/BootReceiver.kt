package com.abrar.vibratescheduler

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val schedules = ScheduleStorage.getAll(context)
            AlarmScheduler.scheduleAll(context, schedules)
        }
    }
}
