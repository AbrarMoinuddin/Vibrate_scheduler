package com.abrar.vibratescheduler

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.abrar.vibratescheduler.databinding.ItemScheduleBinding

class ScheduleAdapter(
    private val schedules: MutableList<Schedule>,
    private val onToggle: (Schedule, Boolean) -> Unit,
    private val onDelete: (Schedule) -> Unit
) : RecyclerView.Adapter<ScheduleAdapter.ViewHolder>() {

    inner class ViewHolder(val binding: ItemScheduleBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemScheduleBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val schedule = schedules[position]
        val binding = holder.binding

        binding.rangeText.text = "Vibrate %02d:%02d \u2192 %02d:%02d".format(
            schedule.onHour, schedule.onMinute, schedule.offHour, schedule.offMinute
        )
        binding.statusText.text = if (schedule.enabled) "Repeats daily" else "Disabled"

        // Avoid triggering the listener while we set the initial state on bind.
        binding.enabledSwitch.setOnCheckedChangeListener(null)
        binding.enabledSwitch.isChecked = schedule.enabled
        binding.enabledSwitch.setOnCheckedChangeListener { _, isChecked ->
            onToggle(schedule, isChecked)
        }

        binding.deleteButton.setOnClickListener { onDelete(schedule) }
    }

    override fun getItemCount(): Int = schedules.size

    fun updateData(newSchedules: List<Schedule>) {
        schedules.clear()
        schedules.addAll(newSchedules)
        notifyDataSetChanged()
    }
}
