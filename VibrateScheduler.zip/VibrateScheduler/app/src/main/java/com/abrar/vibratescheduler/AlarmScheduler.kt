package com.abrar.vibratescheduler

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

/**
 * Schedules two daily alarms per Schedule: one to turn vibrate ON, one to turn it OFF.
 * Each Schedule's ON/OFF alarms use distinct request codes derived from its id so they
 * can be individually updated or cancelled.
 */
object AlarmScheduler {

    const val ACTION_VIBRATE_ON = "com.abrar.vibratescheduler.ACTION_VIBRATE_ON"
    const val ACTION_VIBRATE_OFF = "com.abrar.vibratescheduler.ACTION_VIBRATE_OFF"
    const val EXTRA_SCHEDULE_ID = "schedule_id"

    private fun requestCodeOn(id: Int) = id * 2
    private fun requestCodeOff(id: Int) = id * 2 + 1

    fun scheduleAll(context: Context, schedules: List<Schedule>) {
        schedules.forEach { schedule ->
            if (schedule.enabled) {
                scheduleOne(context, schedule)
            } else {
                cancelOne(context, schedule)
            }
        }
    }

    fun scheduleOne(context: Context, schedule: Schedule) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

        val onIntent = buildPendingIntent(context, schedule.id, ACTION_VIBRATE_ON, requestCodeOn(schedule.id))
        val offIntent = buildPendingIntent(context, schedule.id, ACTION_VIBRATE_OFF, requestCodeOff(schedule.id))

        val onTime = nextTimeMillis(schedule.onHour, schedule.onMinute)
        val offTime = nextTimeMillis(schedule.offHour, schedule.offMinute)

        setExact(alarmManager, onTime, onIntent)
        setExact(alarmManager, offTime, offIntent)
    }

    fun cancelOne(context: Context, schedule: Schedule) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarmManager.cancel(buildPendingIntent(context, schedule.id, ACTION_VIBRATE_ON, requestCodeOn(schedule.id)))
        alarmManager.cancel(buildPendingIntent(context, schedule.id, ACTION_VIBRATE_OFF, requestCodeOff(schedule.id)))
    }

    private fun setExact(alarmManager: AlarmManager, timeMillis: Long, pendingIntent: PendingIntent) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarmManager.canScheduleExactAlarms()) {
            // Fall back to inexact if the user hasn't granted exact-alarm permission.
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timeMillis, pendingIntent)
        } else {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timeMillis, pendingIntent)
        }
    }

    private fun buildPendingIntent(context: Context, scheduleId: Int, action: String, requestCode: Int): PendingIntent {
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            this.action = action
            putExtra(EXTRA_SCHEDULE_ID, scheduleId)
        }
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        return PendingIntent.getBroadcast(context, requestCode, intent, flags)
    }

    /** Returns the next occurrence of hour:minute today, or tomorrow if that time has passed. */
    private fun nextTimeMillis(hour: Int, minute: Int): Long {
        val now = Calendar.getInstance()
        val target = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (target.timeInMillis <= now.timeInMillis) {
            target.add(Calendar.DAY_OF_YEAR, 1)
        }
        return target.timeInMillis
    }
}
