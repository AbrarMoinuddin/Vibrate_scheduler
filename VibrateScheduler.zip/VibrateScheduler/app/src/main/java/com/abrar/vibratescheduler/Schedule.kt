package com.abrar.vibratescheduler

import org.json.JSONObject

/**
 * Represents one vibrate schedule: vibrate mode turns ON at [onHour]:[onMinute]
 * and turns back OFF (normal ringer) at [offHour]:[offMinute], repeating daily
 * while [enabled] is true.
 */
data class Schedule(
    val id: Int,
    var onHour: Int,
    var onMinute: Int,
    var offHour: Int,
    var offMinute: Int,
    var enabled: Boolean = true
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("onHour", onHour)
        put("onMinute", onMinute)
        put("offHour", offHour)
        put("offMinute", offMinute)
        put("enabled", enabled)
    }

    companion object {
        fun fromJson(obj: JSONObject): Schedule = Schedule(
            id = obj.getInt("id"),
            onHour = obj.getInt("onHour"),
            onMinute = obj.getInt("onMinute"),
            offHour = obj.getInt("offHour"),
            offMinute = obj.getInt("offMinute"),
            enabled = obj.getBoolean("enabled")
        )
    }
}
