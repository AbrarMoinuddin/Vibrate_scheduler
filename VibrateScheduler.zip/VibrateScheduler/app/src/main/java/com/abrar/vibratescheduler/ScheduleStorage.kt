package com.abrar.vibratescheduler

import android.content.Context
import org.json.JSONArray

/**
 * Simple JSON-in-SharedPreferences persistence for the schedule list.
 * No database needed for a handful of schedules.
 */
object ScheduleStorage {
    private const val PREFS = "vibrate_scheduler_prefs"
    private const val KEY_SCHEDULES = "schedules"
    private const val KEY_NEXT_ID = "next_id"

    fun getAll(context: Context): MutableList<Schedule> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_SCHEDULES, null) ?: return mutableListOf()
        val arr = JSONArray(raw)
        val list = mutableListOf<Schedule>()
        for (i in 0 until arr.length()) {
            list.add(Schedule.fromJson(arr.getJSONObject(i)))
        }
        return list
    }

    fun saveAll(context: Context, schedules: List<Schedule>) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val arr = JSONArray()
        schedules.forEach { arr.put(it.toJson()) }
        prefs.edit().putString(KEY_SCHEDULES, arr.toString()).apply()
    }

    fun nextId(context: Context): Int {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val id = prefs.getInt(KEY_NEXT_ID, 1)
        prefs.edit().putInt(KEY_NEXT_ID, id + 1).apply()
        return id
    }
}
