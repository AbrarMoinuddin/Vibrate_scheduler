package com.abrar.vibratescheduler

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioManager

class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        // Changing ringer mode on Android 6.0+ requires Do Not Disturb access.
        if (!notificationManager.isNotificationPolicyAccessGranted) {
            // Can't change the ringer without permission; still reschedule so it
            // works automatically once the user grants access.
            rescheduleForTomorrow(context, intent)
            return
        }

        when (intent.action) {
            AlarmScheduler.ACTION_VIBRATE_ON -> audioManager.ringerMode = AudioManager.RINGER_MODE_VIBRATE
            AlarmScheduler.ACTION_VIBRATE_OFF -> audioManager.ringerMode = AudioManager.RINGER_MODE_NORMAL
        }

        rescheduleForTomorrow(context, intent)
    }

    private fun rescheduleForTomorrow(context: Context, intent: Intent) {
        val scheduleId = intent.getIntExtra(AlarmScheduler.EXTRA_SCHEDULE_ID, -1)
        if (scheduleId == -1) return
        val schedule = ScheduleStorage.getAll(context).find { it.id == scheduleId } ?: return
        if (!schedule.enabled) return
        // Re-arm just the alarm that fired (setExact... alarms are one-shot).
        AlarmScheduler.scheduleOne(context, schedule)
    }
}
