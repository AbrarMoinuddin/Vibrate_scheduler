# Vibrate Scheduler

An Android app that automatically switches the phone into vibrate mode and back
to normal ringer mode at times you schedule.

## How it works
- Each **schedule** has a "vibrate ON" time and a "vibrate OFF" time. It repeats daily.
- Add as many schedules as you like, toggle any of them on/off, or delete them.
- Under the hood it uses `AlarmManager` to fire an exact alarm at each time, and
  a `BroadcastReceiver` flips the ringer mode via `AudioManager`.
- Schedules are saved locally (SharedPreferences) and restored automatically
  after a phone restart.

## Required permission (important)
Since Android 6.0, changing ringer/vibrate mode requires **Do Not Disturb
access**. The app shows a yellow banner at the top of the screen until this is
granted — tap it, then enable "Vibrate Scheduler" in the system settings screen
that opens. Without this permission, alarms will still fire and reschedule
correctly, but the ringer mode won't actually change.

On Android 12+, you may also be prompted separately to allow "exact alarms" —
accept this so schedules fire at the precise time rather than being delayed.

## How to build it

### Option A — Get a downloadable APK with no software install (recommended)
This project includes a GitHub Actions workflow that builds the APK in the
cloud automatically. All done via GitHub's website — no command line needed.

1. Go to [github.com](https://github.com) and sign up / log in (free).
2. Click **+ → New repository** (top right). Name it e.g. `vibrate-scheduler`,
   keep it **Public** or **Private** (either works), don't add a README, click
   **Create repository**.
3. On the new empty repo page, click **uploading an existing file** (a link in
   the "Quick setup" section).
4. Unzip `VibrateScheduler.zip` on your computer. Drag the **entire contents**
   of the `VibrateScheduler` folder (not the folder itself — its contents:
   `app/`, `build.gradle.kts`, `.github/`, etc.) into the GitHub upload box.
   GitHub will preserve the folder structure.
5. Scroll down, click **Commit changes**.
6. Click the **Actions** tab at the top of the repo. You should see a
   "Build APK" workflow running (or click **Run workflow** if it didn't start
   automatically). Wait 2–4 minutes for it to finish (green checkmark).
7. Click into the finished run, scroll to **Artifacts**, and download
   `VibrateScheduler-debug-apk` — it's a zip containing `app-debug.apk`.
8. Transfer that `.apk` to your Android phone (email it to yourself, Google
   Drive, USB, etc.) and tap it to install. You'll need to allow "install
   from unknown sources" once when prompted.

This APK is **unsigned/debug-signed** — fine for installing on your own phone,
but not for publishing to the Play Store.

### Option B — Android Studio on your PC
1. Install [Android Studio](https://developer.android.com/studio) (free).
2. Unzip this project, then in Android Studio: **File → Open** → select the
   `VibrateScheduler` folder.
3. Let Gradle sync (first sync downloads dependencies — needs internet).
4. Plug in your Android phone via USB with USB debugging enabled, or use an
   emulator, and click **Run ▶**.

To get an installable APK without a computer connection each time:
**Build → Build Bundle(s) / APK(s) → Build APK(s)**, then find the `.apk` in
`app/build/outputs/apk/debug/` and transfer it to your phone to install.

## Project structure
- `MainActivity.kt` — schedule list UI, add/delete/toggle, permission prompts
- `Schedule.kt` — data model for one schedule
- `ScheduleStorage.kt` — saves/loads schedules as JSON in SharedPreferences
- `AlarmScheduler.kt` — sets/cancels the daily exact alarms
- `AlarmReceiver.kt` — fires when an alarm goes off; changes ringer mode and
  re-arms the next day's alarm
- `BootReceiver.kt` — restores all alarms after the phone reboots

## Customizing
- Want per-day-of-week schedules (e.g. only weekdays)? That's a natural next
  step — the `Schedule` model would need a `daysOfWeek` set and the alarm
  logic would need to skip to the next matching day.
- Want a notification when vibrate mode switches? Add a `NotificationManager`
  call inside `AlarmReceiver`.
